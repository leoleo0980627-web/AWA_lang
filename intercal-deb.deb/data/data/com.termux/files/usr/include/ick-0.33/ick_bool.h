/*
 * Hide difference between compilers with the C99 bool type and those without.
 * The main reason this is desirable is so splint can do more rigorous checking
 * on bools. This also allows for compilers that define _Bool but not true or
 * false, etc.
 */
// SPDX-FileCopyrightText: (C) Eric S. Raymond <esr@thyrsus.com>
// SPDX-License-Identifier: GPL-2.0-or-later

/*@-redef@ -incondefs*/
/*
 * Temporary hack until autonf 2.72 becoomes available.
 * The problen is that autoconf-2.71 does not play well
 * with GCC 15.
 */
#include <stdbool.h>
/*@=redef =incondefs@*/
